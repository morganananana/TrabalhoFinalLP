package br.org.fundatec.view;

import br.org.fundatec.controller.EscolaController;
import br.org.fundatec.exception.AplicacaoException;
import br.org.fundatec.util.TecladoUtil;

import java.util.Calendar;

public class Sistema {

    private static EscolaController controller = new EscolaController();
    private static boolean sair = false;



    public static void main(String[] args) {
        while (!sair) {
            menu();
            int opcao = TecladoUtil.lerInteiro("Informa uma Opcao:");
            executaAcao(opcao);
        }
    }


    private static void executaAcao(int opcao) {
        try {
            switch (opcao) {
                case 1:
                    inserirFuncionario();
                    break;
                case 2:
                    listarFuncionario();
                    break;
                case 3:
                    listarRestaurante();
                    break;
                case 4:
                    cadastrarVoto();
                    break;
                case 5:
                    listarVotos();
                    break;
                case 6:
                    sair = true;
                    break;
                default:
                    System.out.println("Opcao invalida!!");
                    break;
            }
        }catch (AplicacaoException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void inserirFuncionario() throws  AplicacaoException{
        String nome = TecladoUtil.lerString("Informe um nome:");
        String restaurante = TecladoUtil.lerString("Informe uma restaurante:");


        controller.inserirFuncionario(nome, restaurante, Calendar.getInstance());

        System.out.println("Funcionario inserido!");
    }

    private static  void  listarFuncionario() {
        System.out.println(controller.listarFuncionario());
    }

    private static  void  listarRestaurante() {
        System.out.println(controller.listarRestaurante());
    }


    private static  void cadastrarVoto() throws  AplicacaoException {
        Integer idFuncionario = TecladoUtil.lerInteiro("Informa e o codigo do funcionario:");
        String restaurante = TecladoUtil.lerString("Informa o nome da restaurante: ");


        controller.inserirVoto(idFuncionario, restaurante, Calendar.getInstance());
        System.out.println("Voto cadastrada!");

    }

    private static  void  listarVotos() throws  AplicacaoException{
        Integer idVoto = TecladoUtil.lerInteiro("Informa e o codigo do Funcionario:");
        System.out.println(controller.listarVotos(idVoto));
    }

    private static void menu() {
        System.out.println("________________________");
        System.out.println("(1) Cadastrar Funcionario");
        System.out.println("(2) Listar Funcionarios");
        System.out.println("(3) Listar Restaurantes");
        System.out.println("(4) Cadastrar Voto");
        System.out.println("(5) Listar Votos por Funcionario");
        System.out.println("(6) Sair");
        System.out.println("________________________");
    }
}
