package br.org.fundatec.repository;

import br.org.fundatec.model.Funcionario;
import br.org.fundatec.model.Restaurante;
import br.org.fundatec.model.Voto;

import javax.persistence.*;
import java.util.Calendar;
import java.util.List;

public class VotoRepository {
    private EntityManager em;

    public VotoRepository() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("EscolaDB");
        em = factory.createEntityManager();
    }

    public void inserir(Voto voto) {
        this.em.getTransaction().begin();
        this.em.persist(voto);
        this.em.getTransaction().commit();
    }

    public List<Voto> busca(Funcionario funcionario, Calendar data) {
        TypedQuery<Voto> query = this.em.createQuery("select e from Voto e where e.funcionario = :funcionario and e.data = :data", Voto.class);
        query.setParameter("funcionario", funcionario);
        query.setParameter("data", data, TemporalType.DATE);
        try {
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }
    public void atualizar(Voto voto) {
        this.em.merge(voto);
    }
}
