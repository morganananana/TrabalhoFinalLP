package br.org.fundatec.controller;

import br.org.fundatec.exception.AplicacaoException;
import br.org.fundatec.model.Funcionario;
import br.org.fundatec.model.Restaurante;
import br.org.fundatec.model.Voto;
import br.org.fundatec.repository.FuncionarioRepository;
import br.org.fundatec.repository.RestauranteRepository;
import br.org.fundatec.repository.VotoRepository;

import javax.persistence.PersistenceException;
import java.util.Calendar;
import java.util.List;

public class EscolaController {

    private FuncionarioRepository funcionarioRepository;
    private RestauranteRepository restauranteRepository;


    public EscolaController() {
        this.funcionarioRepository = new FuncionarioRepository();
        this.restauranteRepository = new RestauranteRepository();
    }


    public void inserirFuncionario(String nome, String restauranteNome, Calendar data) throws AplicacaoException {
        Restaurante restaurante = restauranteRepository.buscarPorNome(restauranteNome);

        if (restaurante == null) {
            restaurante = new Restaurante(restauranteNome);
        }

        Funcionario funcionario = new Funcionario(nome);
        funcionario.add(new Voto(data, restaurante));

        try {
            funcionarioRepository.inserir(funcionario);
        } catch (PersistenceException e) {
            throw new AplicacaoException("Falha ao inserir Aluno");
        }
    }

    public void inserirVoto(Integer idVoto, String restauranteNome, Calendar data) throws AplicacaoException {
        Voto voto = VotoRepository.inserir(idVoto);

        if (voto == null) {
            throw new AplicacaoException("Funcionario nao encontrado");
        }

        Restaurante restaurante = restauranteRepository.buscarPorNome(restauranteNome);

        if (restaurante == null) {
            restaurante = new Restaurante(restauranteNome);
        }

        voto.add(new Voto(data, restaurante));

        try {
            VotoRepository.atualizar(voto);
        } catch (PersistenceException e) {
            throw new AplicacaoException("Falha ao inserir Voto");
        }
    }

    public List<Funcionario> listarFuncionario() {
        return funcionarioRepository.buscar();
    }

    public List<Restaurante> listarRestaurante() {
        return restauranteRepository.buscar();
    }

    public List<Voto> listarVotos(Integer idVoto) throws AplicacaoException {
        Funcionario funcionario = funcionarioRepository.buscar(idVoto);

        if (funcionario == null) {
            throw new AplicacaoException("Funcionario nao encontrado");
        }

        return funcionario.getVotos();
    }
}
